// age calculator
document.getElementById("message").style.display = "none";
const userName = document.getElementById("input__name");
const birthYear = document.getElementById("input__year");
const currentYear = 2025;
const btnClk = document.getElementById("stBtn");
const scoreBoard = document.getElementById("message");

// logic
btnClk.addEventListener("click", function () {
  if (userName.value == "" || birthYear.value == "") {
    document.getElementById("message").style.display = "block";
    scoreBoard.textContent = "Please enter both your name and DOB";
  } else {
    if (birthYear.value >= 2025 || birthYear.value <= 1900) {
      scoreBoard.textContent = "Enter a valid year";
    } else {
      document.getElementById("message").style.display = "block";
      let userAge = currentYear - Number(birthYear.value);
      scoreBoard.textContent = `Hello ${userName.value}!! You are ${userAge} years old.`;
    }
  }
});
