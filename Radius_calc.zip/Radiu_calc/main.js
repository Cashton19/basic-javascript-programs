//Radius of a cirle

//routing the variables
const submitBtn = document.getElementById("Sbt");
const result = document.getElementsByClassName("message")[0];
const overlay = document.getElementsByClassName("overlay")[0];
const restart = document.getElementById("restartBtn");
const radiusInput = document.getElementById("radius");

//main functions
function calculate() {
  const radius = Number(document.getElementById("radius").value);
  if (radius <= 0) {
    overlay.style.display = "grid";
    result.style.color = "var(--color-error)";
    result.textContent = "Radius can't be less or equal to 0!";
  } else if (isNaN(radius)) {
    overlay.style.display = "grid";
    result.style.color = "var(--color-error)";
    result.textContent = "Invalid Input!";
  } else {
    const area = Math.PI * radius ** 2;
    overlay.style.display = "grid";
    result.textContent = `For Radius ${radius} units, Area would be ${area.toFixed(
      2
    )} square units`;
  }
  restart.style.display = "block";
  overlay.focus();
}

function Restart() {
  overlay.style.display = "none";
  radius.value = "";
  radiusInput.focus();
}

//button event
submitBtn.addEventListener("click", calculate);
radiusInput.addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
    calculate();
  }
});

restart.addEventListener("click", Restart);
overlay.addEventListener("keydown", function (event) {
  if (event.key === "Enter" && overlay.style.display === "grid") {
    Restart();
  }
});
