// defining variables
const principalAmount = document.getElementById("principal__amt");
const intRate = document.getElementById("Interest__rate");
const compoundingFreq = document.getElementById("comp_freq");
const noYears = document.getElementById("years");
const btnClk = document.getElementById("submitBtn");
const result = document.getElementById("infopanel");

// calculations

btnClk.addEventListener("click", () => {
  let finalAmount =
    Number(principalAmount.value) *
    (1 + Number(intRate.value / 100) / Number(compoundingFreq.value)) **
      (Number(compoundingFreq.value) * Number(noYears.value));

  let Comp_int = finalAmount - Number(principalAmount.value);
  document.getElementById("infopanel").style.display = "block";
  result.textContent = `The final amount is Rs.${finalAmount.toFixed(
    2
  )}, out of which the compound interest earned is Rs.${Comp_int.toFixed(2)}.`;
});
